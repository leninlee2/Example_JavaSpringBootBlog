package com.devskiller.tasks.blog.service;


//import java.util.List;
//import java.util.Optional;

import org.springframework.stereotype.Service;

import com.devskiller.tasks.blog.model.Post;
import com.devskiller.tasks.blog.model.dto.PostDto;
import com.devskiller.tasks.blog.repository.PostRepository;

@Service
public class PostService {

	private final PostRepository postRepository;

	public PostService(PostRepository postRepository) {
		this.postRepository = postRepository;
	}

	public PostDto getPost(Long id) {
		return postRepository.findById(id)
				.map(post -> new PostDto(post.getTitle(), post.getContent(), post.getCreationDate()))
				.orElse(null);
	}
	
	public void addPost(PostDto post) {
		Post internal_post = new Post();
		internal_post.setContent(post.getContent());
		internal_post.setCreationDate(post.getCreationDate());
		internal_post.setTitle(post.getTitle());
		postRepository.save(internal_post);
	}
	
}
