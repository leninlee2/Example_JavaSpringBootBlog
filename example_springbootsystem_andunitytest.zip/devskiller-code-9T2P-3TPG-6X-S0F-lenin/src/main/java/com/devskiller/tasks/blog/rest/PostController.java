package com.devskiller.tasks.blog.rest;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.devskiller.tasks.blog.model.dto.CommentDto;
import com.devskiller.tasks.blog.model.dto.NewCommentDto;
import com.devskiller.tasks.blog.model.dto.PostDto;
import com.devskiller.tasks.blog.service.CommentService;
import com.devskiller.tasks.blog.service.PostService;

@Controller
@RestController
@RequestMapping("/posts")
public class PostController {

	private final PostService postService;
	
	private final CommentService commentService;


	public PostController(PostService postService,CommentService commentService) {
		this.postService = postService;
		this.commentService = commentService;
	}

	@GetMapping(value = "/{id}")
	@ResponseStatus(HttpStatus.OK)
	public PostDto getPost(@PathVariable Long id) {
		PostDto result = postService.getPost(id);
		return result;
	}
	
	@GetMapping(value = "addpost/{title}/{content}")
	@ResponseStatus(HttpStatus.OK)
	public void addPost(@PathVariable String title,@PathVariable String content) {
		try {
			LocalDateTime date = LocalDateTime.now();
			PostDto newpost = new PostDto(title,content,date);
			postService.addPost(newpost);	
		}catch(Exception ex) {
			throw ex;
		}
		
	}
	
	@GetMapping(value = "/{id}/comments")
	@ResponseStatus(HttpStatus.OK)
	public List<CommentDto> getCommentsByPost(@PathVariable Long id) {
		List<CommentDto> result = new ArrayList<CommentDto>();
		try {
		  result = commentService.getCommentsForPost(id);
		}catch(Exception ex) {
			throw ex;
		}
		return result;
	}
	
	//@PostMapping(value = "/{id}/comments")
	@RequestMapping(value = "/{id}/{comments}", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public List<NewCommentDto> setCommentsByPost(@PathVariable Long id,@PathVariable String comments) {
		List<NewCommentDto> result = new ArrayList<NewCommentDto>();
		try {
			NewCommentDto newCommentDto = new NewCommentDto();
			newCommentDto.setAuthor("example author");
			newCommentDto.setContent(comments);
			newCommentDto.setPostId(id);
			commentService.addComment(newCommentDto);	
			result.add(newCommentDto);
		}catch(Exception ex) {
			throw ex;
		}
		
		return result;
	}

}
